package com.ayi.trabajo_final;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ayitrabajoFinalappTests {

	@Test
	void contextLoads() {
	}

}

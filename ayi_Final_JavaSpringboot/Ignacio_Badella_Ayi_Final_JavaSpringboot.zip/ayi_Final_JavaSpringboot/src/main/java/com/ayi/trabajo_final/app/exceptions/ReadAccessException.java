package com.ayi.trabajo_final.app.exceptions;

public class ReadAccessException extends Exception{

    public ReadAccessException(String message) {
        super(message);
    }
}
